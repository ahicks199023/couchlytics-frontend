import SyncDashboard from '@/components/SyncDashboard'

export default function Page() {
  return <SyncDashboard />
}
